#!/bin/bash

folder_directory="~/ray_results/LightningTrainer_2023-07-08_14-18-31"

for folder in "${folder_directory}"/*; do
    echo "hi"
    if [[ -d "${folder}" ]]; then
        new_name=$(basename "${folder}" | cut -d "_" -f 1)
        new_folder="${folder_directory}/${new_name}"
        # mv "${folder}" "${new_folder}"
        echo "Renamed ${folder} to ${new_folder}"
    fi
done

